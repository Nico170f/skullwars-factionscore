package me.nico.core.Events;

import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityShootBowEvent;

import me.nico.core.Main;

public class ShootBowEvent implements Listener {

	private Main main;
	// private Plugin plugin = IPBlocker.getPlugin(IPBlocker.class);

	public ShootBowEvent(Main main) {
		this.main = main;
	}

	@EventHandler
	public void onBowFire(EntityShootBowEvent event) {
		if (event.getEntityType().equals(org.bukkit.entity.EntityType.PLAYER)) {
			try {
				Player parsePlayer = Bukkit.getServer().getPlayer(event.getEntity().getName().toString());

				String world = parsePlayer.getWorld().getName();
				List<String> list = main.getConfig().getStringList("AntiBow.Worlds");

				if (list.contains(world)) {
					event.setCancelled(true);
				}

			} catch (Exception e) {
				Bukkit.getLogger().warning("Unknown error...");
				e.printStackTrace();
			}
		}

	}
}
