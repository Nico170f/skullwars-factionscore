package me.nico.core.Events;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

import com.massivecraft.factions.FPlayer;
import com.massivecraft.factions.FPlayers;
import com.massivecraft.factions.perms.Role;

import me.nico.core.Main;
import me.nico.core.utils.Color;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;

public class DeathAnnounce implements Listener {
	private Main main;

	public DeathAnnounce(Main main) {
		this.main = main;
	}

	@EventHandler
	public void onPlayerDeathEvent(PlayerDeathEvent event) {

		if (!main.getConfig().getBoolean("DeathAnnouncer.enabled")) {
			return;
		}

		Player player = event.getEntity();

		Player pKiller = null;
		try {
			pKiller = player.getKiller();
			if (pKiller == null) {
				return;
			}
		} catch (Exception e) {
			System.out.print(e);
		}

		FPlayer fPlayer = FPlayers.getInstance().getByPlayer(Bukkit.getServer().getPlayer(player.getName()));

		StringBuilder normalStrB = new StringBuilder();
		List<String> normalList = main.getConfig().getStringList("DeathAnnouncer.Messages.normal-messages");
		int normalCounter = 0;
		for (String str : normalList) {
			normalCounter++;
			normalStrB.append(str);
			if (normalList.size() > normalCounter) {
				normalStrB.append("\n");
			}
		}

		String partnerPermission = main.getConfig().getString("DeathAnnouncer.config.Partner_permission");
		String staffPermission = main.getConfig().getString("DeathAnnouncer.config.Staff_permission");
		String full = normalStrB.toString();

		Boolean soundOn = false;
		if (main.getConfig().getBoolean("DeathAnnouncer.groups.normal") == true) {
			soundOn = true;
		}

		if (fPlayer.getRole().equals(Role.ADMIN) || fPlayer.getRole().equals(Role.COLEADER)) {
			StringBuilder leaderStrB = new StringBuilder();
			List<String> leaderList = main.getConfig().getStringList("DeathAnnouncer.Messages.leader-messages");
			int leaderCounter = 0;
			for (String str : leaderList) {
				leaderCounter++;
				leaderStrB.append(str);
				if (leaderList.size() > leaderCounter) {
					leaderStrB.append("\n");
				}
			}
			full = leaderStrB.toString();
			soundOn = false;
			if (main.getConfig().getBoolean("DeathAnnouncer.groups.FacOwner") == true) {
				soundOn = true;
			}
		}

		if (player.hasPermission(partnerPermission)) {
			StringBuilder partnerStrB = new StringBuilder();
			List<String> partnerList = main.getConfig().getStringList("DeathAnnouncer.Messages.partner-messages");
			int partnerCounter = 0;
			for (String str : partnerList) {
				partnerCounter++;
				partnerStrB.append(str);
				if (partnerList.size() > partnerCounter) {
					partnerStrB.append("\n");
				}
			}
			full = partnerStrB.toString();
			soundOn = false;
			if (main.getConfig().getBoolean("DeathAnnouncer.groups.partner") == true) {
				soundOn = true;
			}
		}
		if (player.hasPermission(staffPermission)) {
			StringBuilder staffStrB = new StringBuilder();
			List<String> staffList = main.getConfig().getStringList("DeathAnnouncer.Messages.staff-messages");
			int staffCounter = 0;
			for (String str : staffList) {
				staffCounter++;
				staffStrB.append(str);
				if (staffList.size() > staffCounter) {
					staffStrB.append("\n");
				}
			}
			full = staffStrB.toString();
			soundOn = false;
			if (main.getConfig().getBoolean("DeathAnnouncer.groups.staff") == true) {
				soundOn = true;
			}
		}

		ItemStack item = pKiller.getItemInHand();
		String name;

		ArrayList<String> loreArray = new ArrayList<String>();
		List<String> enchantmentlist = new ArrayList<String>();

		if (item == null) {
			name = "null";
		} else if (item.getItemMeta() == null) {
			name = item.getType().toString();
			if (item.getType() == null || item.getType() == Material.AIR) {
				name = main.getConfig().getString("DeathAnnouncer.Special_Items.Hand");
			}

		} else if (item.getItemMeta().getDisplayName() == null) {
			name = item.getType().toString();
			if (item.getType() == Material.DIAMOND_HOE) {
				name = main.getConfig().getString("DeathAnnouncer.Special_Items.Hoe");
			}

		} else {
			name = item.getItemMeta().getDisplayName();
			if (item.getType() != Material.BOW) {
				if (item.getItemMeta().getLore() != null) {
					List<String> lores = item.getItemMeta().getLore();
					for (String s : lores) {
						loreArray.add(s);
					}
				}

			}

		}

		if (item.getType() == Material.DIAMOND_SWORD || item.getType() == Material.BOW
				|| item.getType() == Material.DIAMOND_AXE || item.getType() == Material.DIAMOND_PICKAXE) {
			if (item.containsEnchantment(Enchantment.DAMAGE_ALL)) {
				int value = item.getEnchantmentLevel(Enchantment.DAMAGE_ALL);
				enchantmentlist.add("Sharpness " + value);
			}
			if (item.containsEnchantment(Enchantment.DAMAGE_UNDEAD)) {
				int value = item.getEnchantmentLevel(Enchantment.DAMAGE_UNDEAD);
				enchantmentlist.add("Smite " + value);
			}
			if (item.containsEnchantment(Enchantment.DAMAGE_ARTHROPODS)) {
				int value = item.getEnchantmentLevel(Enchantment.DAMAGE_ARTHROPODS);
				enchantmentlist.add("Bane Of Arthropods " + value);
			}
			if (item.containsEnchantment(Enchantment.KNOCKBACK)) {
				int value = item.getEnchantmentLevel(Enchantment.KNOCKBACK);
				enchantmentlist.add("Knockback " + value);
			}
			if (item.containsEnchantment(Enchantment.FIRE_ASPECT)) {
				int value = item.getEnchantmentLevel(Enchantment.FIRE_ASPECT);
				enchantmentlist.add("Fire Aspect " + value);
			}
			if (item.containsEnchantment(Enchantment.LOOT_BONUS_MOBS)) {
				int value = item.getEnchantmentLevel(Enchantment.LOOT_BONUS_MOBS);
				enchantmentlist.add("Looting " + value);
			}
			if (item.containsEnchantment(Enchantment.ARROW_DAMAGE)) {
				int value = item.getEnchantmentLevel(Enchantment.ARROW_DAMAGE);
				enchantmentlist.add("Power " + value);
			}
			if (item.containsEnchantment(Enchantment.ARROW_KNOCKBACK)) {
				int value = item.getEnchantmentLevel(Enchantment.ARROW_KNOCKBACK);
				enchantmentlist.add("Punch " + value);
			}
			if (item.containsEnchantment(Enchantment.ARROW_FIRE)) {
				int value = item.getEnchantmentLevel(Enchantment.ARROW_FIRE);
				enchantmentlist.add("Flame " + value);
			}
			if (item.containsEnchantment(Enchantment.ARROW_INFINITE)) {
				int value = item.getEnchantmentLevel(Enchantment.ARROW_INFINITE);
				enchantmentlist.add("Infinity " + value);
			}
			if (item.containsEnchantment(Enchantment.DURABILITY)) {
				int value = item.getEnchantmentLevel(Enchantment.DURABILITY);
				enchantmentlist.add("Unbreaking " + value);
			}
		}

		TextComponent tc = new TextComponent();
		tc.setText(Color.color(full.replace("{PLAYER}", player.getName()).replace("{KILLER}", pKiller.getName())
				.replace("{ITEM}", name)));

		if (enchantmentlist.size() == 0 && loreArray.size() == 0) {
			tc.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("" + name).create()));
		}

		if (enchantmentlist.size() != 0 && loreArray.size() == 0) {
			tc.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("" + name + "\n"
					+ ChatColor.GRAY
					+ enchantmentlist.toString().replace(", ", "\n" + ChatColor.GRAY).replace("[", "").replace("]", ""))
							.create()));
		}

		if (enchantmentlist.size() == 0 && loreArray.size() != 0) {
			tc.setHoverEvent(
					new HoverEvent(HoverEvent.Action.SHOW_TEXT,
							new ComponentBuilder("" + name + "\n"
									+ loreArray.toString().replace(", ", "\n").replace("[", "").replace("]", ""))
											.create()));
		}

		if (enchantmentlist.size() != 0 && loreArray.size() != 0) {
			tc.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
					new ComponentBuilder("" + name + "\n" + ChatColor.GRAY
							+ enchantmentlist.toString().replace(", ", "\n" + ChatColor.GRAY).replace("[", "")
									.replace("]", "")
							+ "\n" + loreArray.toString().replace(", ", "\n").replace("[", "").replace("]", ""))
									.create()));
		}

		for (Player p : Bukkit.getOnlinePlayers()) {
			p.spigot().sendMessage(tc);
		}

		if (main.getConfig().getBoolean("DeathAnnouncer.soundOn")) {
			if (soundOn == true) {
				for (Player all : Bukkit.getServer().getOnlinePlayers()) {
					all.playSound(all.getLocation(), Sound.ORB_PICKUP, 1, 1);
				}
			}
		}
	}
}