package me.nico.core.Events;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import me.nico.core.Main;
import me.nico.core.utils.Color;

public class LmsFix implements Listener {

	private Main main;
	// private Plugin plugin = IPBlocker.getPlugin(IPBlocker.class);

	public LmsFix(Main main) {
		this.main = main;
	}

	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event) {
		Player player = event.getPlayer();
		
		if (main.getConfig().getBoolean("LMSFix.enabled")) {

			String loginWorld = main.getConfig().getString("LMSFix.world");
			if (player.getWorld().getName().equalsIgnoreCase(loginWorld)) {
				String permission = main.getConfig().getString("LMSFix.bypass_permission");
				if (player.hasPermission(permission)) {
					player.sendMessage(Color.color(main.getConfig().getString("LMSFix.bypass_message")));
					return;
				} else {
					String sendMsg = main.getConfig().getString("LMSFix.chat_message");
					player.setHealth(0);
					player.sendMessage(
							Color.color(sendMsg.replace("{WORLD}", loginWorld)));
				}

			}
		} else {
			return;
		}
	}

}
