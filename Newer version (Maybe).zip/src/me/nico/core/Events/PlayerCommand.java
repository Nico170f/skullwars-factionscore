package me.nico.core.Events;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.scheduler.BukkitScheduler;

import me.nico.core.Main;
import me.nico.core.utils.Color;

public class PlayerCommand implements Listener {
	private Main main;

	public PlayerCommand(Main main) {
		this.main = main;
	}

	@EventHandler
	public void onPlayerCommandPreprocess(final PlayerCommandPreprocessEvent e) {
		Player Sender = e.getPlayer();
		final String message = e.getMessage();
		if (message.startsWith("/tpa ") || message.startsWith("/etpa ")) {
			final String[] parts = message.split(" ");
			final String playerName = parts[1].toLowerCase();
			Player FoundPlayer = null;
			try {
				FoundPlayer = Bukkit.getServer().getPlayer(playerName);
			} catch (Exception e2) {
				return;
			}

			final Player finalplayer = FoundPlayer;

			BukkitScheduler scheduler2 = main.getServer().getScheduler();
			if(FoundPlayer.getWorld().getName().equalsIgnoreCase(main.getConfig().getString("Friends.blocked_world"))) {
				scheduler2.scheduleSyncDelayedTask(this.main, new Runnable() {
					public void run() {
						Sender.sendMessage(Color.color(main.getConfig().getString("Friends.in_blocked_world")
								.replace("{PLAYER}", finalplayer.getName())));
						return;
					}
				}, 1);
				return;
			}
			
			if (!main.getFriendConfig().contains("Users." + FoundPlayer.getUniqueId())) {
				BukkitScheduler scheduler1 = main.getServer().getScheduler();
				scheduler1.scheduleSyncDelayedTask(this.main, new Runnable() {
					public void run() {
						finalplayer.sendMessage(Color.color(main.getConfig().getString("Friends.feature_alert")
								.replace("{PLAYER}", Sender.getName())));
						return;
					}
				}, 1);// 1L
				return;
			}

			if (main.getFriendConfig().getBoolean("Users." + FoundPlayer.getUniqueId() + ".enabled")) {
				if (main.getFriendConfig().getStringList("Users." + FoundPlayer.getUniqueId() + ".name")
						.contains(Sender.getName().toString())) {

					BukkitScheduler scheduler = main.getServer().getScheduler();
					scheduler.scheduleSyncDelayedTask(this.main, new Runnable() {
						@Override
						public void run() {
							finalplayer.chat("/tpaccept");
							finalplayer.sendMessage(Color.color(main.getConfig()
									.getString("Friends.messages.accepted_tpa").replace("{PLAYER}", Sender.getName())));

							if (main.getConfig().getBoolean("Friends.sound_autoaccept")) {
								try {
									Sender.playSound(Sender.getLocation(),
											Sound.valueOf(main.getConfig().getString("Friends.sound")), 1, 1);
									finalplayer.playSound(finalplayer.getLocation(),
											Sound.valueOf(main.getConfig().getString("Friends.sound")), 1, 1);
								} catch (Exception e2) {
									System.out.print(e2);
								}
							}
							return;
						}
					}, 1);// 1L

				}
			}
		}
	}
}
