package me.nico.core.Commands;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;

import me.nico.core.Main;
import me.nico.core.utils.Color;
import net.md_5.bungee.api.ChatColor;

public class DarkZoneStuckCMD implements CommandExecutor, Listener {

	private Main main;
	public static List<UUID> playersCancel = new ArrayList<UUID>();
	public static List<UUID> players = new ArrayList<UUID>();
	private final Map<UUID, Long> cooldownsRefill = new HashMap<>();

	public DarkZoneStuckCMD(Main main) {
		this.main = main;
	}

	public void setCooldownRefill(UUID player, long l) {
		if (l < 1) {
			cooldownsRefill.remove(player);
		} else {
			cooldownsRefill.put(player, l);
		}
	}

	public Long getCooldownRefill(UUID player) {
		return cooldownsRefill.getOrDefault(player, (long) 0);
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		if (sender instanceof Player) {
			Player player = (Player) sender;
			if (!main.getConfig().getBoolean("DarkzoneStuck.enabled")) {
				player.sendMessage(ChatColor.RED + "This is currently disabled.");
				return true;
			}

			String world = main.getConfig().getString("DarkzoneStuck.world");
			if (!player.getWorld().getName().equalsIgnoreCase(world)) {
				player.sendMessage(
						Color.color(main.getConfig().getString("DarkzoneStuck.wrong_world")).replace("{WORLD}", world));
				return true;
			}
			
			
			World tpWorld = Bukkit.getServer().getWorld(main.getConfig().getString("DarkzoneStuck.teleport_location.world"));
			int x = main.getConfig().getInt("DarkzoneStuck.teleport_location.x");
			int y = main.getConfig().getInt("DarkzoneStuck.teleport_location.y");
			int z = main.getConfig().getInt("DarkzoneStuck.teleport_location.z");

			long timeLeft = System.currentTimeMillis() - getCooldownRefill(player.getUniqueId());
			if (TimeUnit.MILLISECONDS.toSeconds(timeLeft) >= main.getConfig()
					.getInt("DarkzoneStuck.command_cooldown")) {
				setCooldownRefill(player.getUniqueId(), System.currentTimeMillis());

				players.add(player.getUniqueId());
				//Location spawn = player.getServer().getWorld(main.getConfig().getString("DarkzoneStuck.tp_world")).getSpawnLocation();

				Location loc = player.getLocation();
				for (Player p : Bukkit.getOnlinePlayers()) {
					if (p.getWorld().getName().equals(main.getConfig().getString("DarkzoneStuck.world"))) {
						p.sendMessage(Color.color(main.getConfig().getString("DarkzoneStuck.world_announce"))
								.replace("{PLAYER}", player.getName())
								.replace("{X}", loc.getBlockX() + "").replace("{Y}", loc.getBlockY() + "").replace("{Z}", loc.getBlockZ() + ""));
					}
				}

				String timerMsg = main.getConfig().getString("DarkzoneStuck.timer_message");
				new BukkitRunnable() {
					int teleportTimer = main.getConfig().getInt("DarkzoneStuck.tp_timer");

					public void run() {

						if (playersCancel.contains(player.getUniqueId())) {
							players.remove(player.getUniqueId());
							playersCancel.remove(player.getUniqueId());
							player.sendMessage(Color.color(main.getConfig().getString("DarkzoneStuck.tp_cancelled")));
							cancel();
						} else {
							player.sendMessage(Color.color(timerMsg).replace("{TIMER}", teleportTimer + ""));
							teleportTimer--;
							if (teleportTimer <= 0) {
								players.remove(player.getUniqueId());
								try {
									
									player.teleport(new Location(tpWorld, x, y, z));
									if (main.getConfig().getBoolean("DarkzoneStuck.send_message_on_teleport")) {
										player.sendMessage(
												Color.color(main.getConfig().getString("DarkzoneStuck.tp_message")));
									}
								} catch (Exception e) {
									player.sendMessage(ChatColor.RED + "Error occured");
								}
								cancel();
							}
						}
					}
				}.runTaskTimer(main, 0, 20);

				return true;
			} else {
				// System.out.print(TimeUnit.MILLISECONDS.toSeconds(timeLeft));
				long mustWait = main.getConfig().getInt("DarkzoneStuck.command_cooldown")
						- TimeUnit.MILLISECONDS.toSeconds(timeLeft);
				String wait = mustWait + "s";
				if (mustWait > 59) {
					wait = formatSecondDateTime(mustWait);
				}

				player.sendMessage(Color.color(main.getConfig().getString("DarkzoneStuck.cooldown_message"))
						.replace("{COOLDOWN}", wait + ""));
			}
		} else {
			sender.sendMessage("This command can only be done by players.");
		}
		return true;
	}

	@EventHandler
	public void PlayerMove(PlayerMoveEvent event) {
		if (event.getTo().getBlockX() == event.getFrom().getBlockX()
				&& event.getTo().getBlockY() == event.getFrom().getBlockY()
				&& event.getTo().getBlockZ() == event.getFrom().getBlockZ())
			return;

		Player player = event.getPlayer();
		if (playersCancel.contains(player.getUniqueId()))
			return;
		if (players.contains(player.getUniqueId())) {
			playersCancel.add(player.getUniqueId());
		}
	}

	@EventHandler
	public void PlayerDamage(EntityDamageByEntityEvent event) {
		Entity damager = event.getDamager();// Bukkit.broadcastMessage(damager.getName());
		if (playersCancel.contains(damager.getUniqueId())) {
			return;
		}
		if (players.contains(damager.getUniqueId())) {
			playersCancel.add(damager.getUniqueId());
		}
	}

	@EventHandler
	public void PlayerTakeDamage(EntityDamageEvent event) {
		Entity entity = event.getEntity();// Bukkit.broadcastMessage(entity.getName() + " took damage");
		if (playersCancel.contains(entity.getUniqueId())) {
			return;
		}
		if (players.contains(entity.getUniqueId())) {
			playersCancel.add(entity.getUniqueId());
		}
	}

	public static String formatSecondDateTime(long mustWait) {
		if (mustWait <= 0)
			return "";
		int m = (int) (mustWait % 3600 / 60);
		int s = (int) (mustWait % 60);
		return m + "m, " + s + "s";
	}
}
