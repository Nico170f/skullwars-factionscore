package me.nico.core.Commands;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import io.netty.util.internal.ThreadLocalRandom;
import me.nico.core.Main;
import me.nico.core.utils.Color;
import net.md_5.bungee.api.ChatColor;

public class RaidOutpost implements CommandExecutor {

	private Main main;

	public RaidOutpost(Main main) {
		this.main = main;
	}

	private final Map<UUID, Long> cooldownsRefill = new HashMap<>();

	public void setCooldownRefill(UUID player, long l) {
		if (l < 1) {
			cooldownsRefill.remove(player);
		} else {
			cooldownsRefill.put(player, l);
		}
	}

	public Long getCooldownRefill(UUID player) {
		return cooldownsRefill.getOrDefault(player, (long) 0);
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

		if (sender instanceof Player) {
			Player player = (Player) sender;
			if (!main.getConfig().getBoolean("RaidOutPostTP.enabled")) {
				player.sendMessage(ChatColor.RED + "This is currently disabled.");
				return true;
			}

			long timeLeft = System.currentTimeMillis() - getCooldownRefill(player.getUniqueId());
			// long newTime = System.currentTimeMillis()
			if (TimeUnit.MILLISECONDS.toSeconds(timeLeft) >= main.getConfig().getInt("RaidOutPostTP.cooldown")) {
				setCooldownRefill(player.getUniqueId(), System.currentTimeMillis());

				int xmax = main.getConfig().getInt("RaidOutPostTP.coords.x.max") - 10;// 100 - 10;
				int xmin = (main.getConfig().getInt("RaidOutPostTP.coords.x.min")) + 10;

				int ymax = main.getConfig().getInt("RaidOutPostTP.coords.y.max") - 10;
				int ymin = (main.getConfig().getInt("RaidOutPostTP.coords.y.min")) + 10;
				int z = main.getConfig().getInt("RaidOutPostTP.coords.z");

				int x = ThreadLocalRandom.current().nextInt(xmin, xmax);
				int y = ThreadLocalRandom.current().nextInt(ymin, ymax);

				World w = null;
				try {
					w = Bukkit.getServer().getWorld(main.getConfig().getString("RaidOutPostTP.world"));
				} catch (Exception e) {
					player.sendMessage(ChatColor.RED
							+ "There was an error issuing this command. Please report this in the SkullWars Discord.");
					return true;
				}

				if (w != null) {
					player.teleport(new Location(w, x, z, y));
					if (main.getConfig().getBoolean("RaidOutPostTP.send_message_on_teleport")) {
						player.sendMessage(Color.color(main.getConfig().getString("RaidOutPostTP.tp_message")));
					} else {
						player.sendMessage(ChatColor.RED
								+ "There was an error issuing this command. Please report this in the SkullWars Discord.");
						return true;
					}
				} else {
					player.sendMessage(ChatColor.RED
							+ "There was an error issuing this command. Please report this in the SkullWars Discord.");
					return true;
				}
				return true;
			} else {
				// System.out.print(TimeUnit.MILLISECONDS.toSeconds(timeLeft));
				long mustWait = main.getConfig().getInt("RaidOutPostTP.cooldown")
						- TimeUnit.MILLISECONDS.toSeconds(timeLeft);
				String wait = mustWait + "s";
				if (mustWait > 59) {
					wait = formatSecondDateTime(mustWait);
				}

				player.sendMessage(Color.color(main.getConfig().getString("RaidOutPostTP.coondown_message"))
						.replace("{COOLDOWN}", wait + ""));
			}
		} else {
			sender.sendMessage("Player-only command");
		}
		return true;
	}

	public static String formatSecondDateTime(long mustWait) {
		if (mustWait <= 0)
			return "";
		int m = (int) (mustWait % 3600 / 60);
		int s = (int) (mustWait % 60);
		return m + "m, " + s + "s";
	}

	/*
	 * @Override public boolean onCommand(CommandSender sender, Command cmd, String
	 * label, String[] args) { if (sender instanceof Player) { Player player =
	 * (Player) sender;
	 * 
	 * if (!main.getConfig().getBoolean("RaidOutPostTP.enabled")) {
	 * player.sendMessage(ChatColor.RED + "This is currently disabled."); return
	 * true; }
	 * 
	 * int xmax = main.getConfig().getInt("RaidOutPostTP.coords.x.max") - 10;// 100
	 * - 10; int xmin = (main.getConfig().getInt("RaidOutPostTP.coords.x.min")) +
	 * 10;
	 * 
	 * int ymax = main.getConfig().getInt("RaidOutPostTP.coords.y.max") - 10; int
	 * ymin = (main.getConfig().getInt("RaidOutPostTP.coords.y.min")) + 10; int z =
	 * main.getConfig().getInt("RaidOutPostTP.coords.z");
	 * 
	 * int x = ThreadLocalRandom.current().nextInt(xmin, xmax); int y =
	 * ThreadLocalRandom.current().nextInt(ymin, ymax);
	 * 
	 * World w = null; try { w =
	 * Bukkit.getServer().getWorld(main.getConfig().getString("RaidOutPostTP.world")
	 * ); } catch (Exception e) { player.sendMessage(ChatColor.RED +
	 * "There was an error issuing this command. Please report this in the SkullWars Discord."
	 * ); return true; }
	 * 
	 * if (w != null) { player.teleport(new Location(w, x, z, y)); if
	 * (main.getConfig().getBoolean("RaidOutPostTP.send_message_on_teleport")) {
	 * player.sendMessage(ChatColor.translateAlternateColorCodes('&',
	 * main.getConfig().getString("RaidOutPostTP.tp_message"))); } }
	 * 
	 * 
	 * 
	 * return true; } else {
	 * System.out.print("This command can only be done by players!"); return false;
	 * } }
	 */
}
