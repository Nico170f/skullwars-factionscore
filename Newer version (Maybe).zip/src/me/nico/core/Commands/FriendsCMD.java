package me.nico.core.Commands;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.nico.core.Main;
import me.nico.core.utils.Color;

public class FriendsCMD implements CommandExecutor {

	private Main main;

	public FriendsCMD(Main main) {
		this.main = main;
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (sender instanceof Player) {
			Player player = (Player) sender;

			if (!main.getConfig().getBoolean("Friends.enabled")) {
				player.sendMessage(Color.color(main.getConfig().getString("Friends.disabled_message")));
				return true;
			}

			if (args.length == 0) {
				StringBuilder menu = new StringBuilder();
				List<String> msgList = main.getConfig().getStringList("Friends.messages.menu");
				for (String str : msgList) {
					menu.append(str + "\n");
				}
				String finalMessage = menu.toString();
				String status = main.getConfig().getString("Friends.status.disabled");

				if (main.getFriendConfig().contains("Users." + player.getUniqueId())) {
					if (main.getFriendConfig().getBoolean("Users." + player.getUniqueId() + ".enabled")) {
						status = main.getConfig().getString("Friends.status.enabled");
					}
				}

				player.sendMessage(Color.color(finalMessage.replace("{STATUS}", status)));
				return true;
			}
			if (args.length >= 1) {
				if (args[0].equalsIgnoreCase("add")) {
					if (args.length < 2) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.wrong_syntax")));
						return true;
					}

					if (player.getName().equalsIgnoreCase(args[1])) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.add_self")));
						return true;
					}

					if (main.getFriendConfig().contains("Users." + player.getUniqueId())) {

						List<String> FriendList = main.getFriendConfig()
								.getStringList("Users." + player.getUniqueId() + ".name");
						boolean searchStr = FriendList.stream().anyMatch(args[1]::equalsIgnoreCase);

						if (searchStr) {
							player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.already_added")
									.replace("{PLAYER}", args[1])));
							return true;
						}
					}

					if(!Bukkit.getOfflinePlayer(args[1]).hasPlayedBefore()) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.not_found")
								.replace("{PLAYER}", args[1])));
					return true;
					}
					
					
					
					List<String> adds = new ArrayList<>(
							main.getFriendConfig().getStringList("Users." + player.getUniqueId() + ".name"));
					adds.add(args[1]);

					if (!main.getFriendConfig().contains("Users." + player.getUniqueId())) {
						main.getFriendConfig().set("Users." + player.getUniqueId() + ".enabled", true);
					}
					main.getFriendConfig().set("Users." + player.getUniqueId() + ".name", adds);

					try {
						main.getFriendConfig().save(main.friendFile);
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.user_added")
								.replace("{PLAYER}", args[1])));
						return true;
					} catch (Exception e) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.error_occured")));
						return true;
					}

				} else if (args[0].equalsIgnoreCase("remove")) {

					if (!main.getFriendConfig().contains("Users." + player.getUniqueId())) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.no_friends")));
						return true;
					}

					if (args.length < 2) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.wrong_syntax")));
						return true;
					}

					if (player.getName().equalsIgnoreCase(args[1])) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.remove_self")));
						return true;
					}

					if (!main.getFriendConfig().getStringList("Users." + player.getUniqueId() + ".name")
							.contains(args[1])) {
						player.sendMessage(Color.color(
								main.getConfig().getString("Friends.messages.not_added").replace("{PLAYER}", args[1])));
						return true;

					} else {

						List<String> addslist = new ArrayList<>();
						addslist = main.getFriendConfig().getStringList("Users." + player.getUniqueId() + ".name");
						addslist.remove(args[1]);
						main.getFriendConfig().set("Users." + player.getUniqueId() + ".name", addslist);

						try {
							main.getFriendConfig().save(main.friendFile);
							player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.user_removed")
									.replace("{PLAYER}", args[1])));
							return true;
						} catch (Exception e) {
							player.sendMessage(Color.color(main.getConfig().getString("Friends.error_occured")));
							return true;
						}

					}

				} else if (args[0].equalsIgnoreCase("toggle")) {

					String send = null;
					if (main.getFriendConfig().contains("Users." + player.getUniqueId())) {
						if (main.getFriendConfig().getBoolean("Users." + player.getUniqueId() + ".enabled")) {
							main.getFriendConfig().set("Users." + player.getUniqueId() + ".enabled", false);
							send = main.getConfig().getString("Friends.messages.disabled_friends");
						} else {
							send = main.getConfig().getString("Friends.messages.enabled_friends");
							main.getFriendConfig().set("Users." + player.getUniqueId() + ".enabled", true);
						}

						try {
							main.getFriendConfig().save(main.friendFile);
							player.sendMessage(Color.color(send));
							return true;

						} catch (Exception e) {
							player.sendMessage(Color.color(main.getConfig().getString("Friends.error_occured")));
							return true;
						}
					} else {
						main.getFriendConfig().set("Users." + player.getUniqueId() + ".enabled", true);

						try {

							player.sendMessage(
									Color.color(main.getConfig().getString("Friends.messages.enabled_friends")));
							main.getFriendConfig().save(main.friendFile);

							return true;
						} catch (Exception e) {
							player.sendMessage(Color.color(main.getConfig().getString("Friends.error_occured")));
							return true;
						}

					}

				} else if (args[0].equalsIgnoreCase("list")) {

					if (!main.getFriendConfig().contains("Users." + player.getUniqueId())) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.no_friends")));
						return true;
					}
					if (main.getFriendConfig().getStringList("Users." + player.getUniqueId() + ".name").size() < 1) {
						player.sendMessage(Color.color(main.getConfig().getString("Friends.messages.no_friends")));
						return true;
					}

					StringBuilder friendList = new StringBuilder();
					friendList.append(Color.color(main.getConfig().getString("Friends.messages.list_header") + "\n"));

					List<String> addedList = main.getFriendConfig()
							.getStringList("Users." + player.getUniqueId() + ".name");

					int count = 1;
					for (String str : addedList) {
						friendList.append(Color.color(main.getConfig().getString("Friends.messages.list_format")
								.replace("{LIST}", str).replace("{COUNT}", count + "") + "\n"));
						count++;
					}
					String finalMessage = friendList.toString();
					player.sendMessage(finalMessage);
					return true;

				} else {
					player.sendMessage(
							Color.color(main.getConfig().getString("Friends.cmd_not_found").replace("{CMD}", args[0])));
					return true;
				}

			}

			return true;
		} else {
			return false;
		}
	}

	/*
	 * private String getName(String uuid) { String url =
	 * "https://api.mojang.com/user/profiles/"+uuid.replace("-", "")+"/names"; try {
	 * 
	 * @SuppressWarnings("deprecation") String nameJson = IOUtils.toString(new
	 * URL(url)); JSONArray nameValue = (JSONArray)
	 * JSONValue.parseWithException(nameJson); String playerSlot =
	 * nameValue.get(nameValue.size()-1).toString(); JSONObject nameObject =
	 * (JSONObject) JSONValue.parseWithException(playerSlot); return
	 * nameObject.get("name").toString(); } catch (IOException | ParseException e) {
	 * e.printStackTrace(); } return "error"; }
	 */

}
