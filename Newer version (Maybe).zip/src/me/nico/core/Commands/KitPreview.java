package me.nico.core.Commands;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import com.earth2me.essentials.CommandSource;
import com.earth2me.essentials.IEssentials;
import com.earth2me.essentials.Kit;
import com.earth2me.essentials.MetaItemStack;

import de.themoep.inventorygui.GuiElement;
import de.themoep.inventorygui.InventoryGui;
import de.themoep.inventorygui.StaticGuiElement;
import me.nico.core.Main;
import me.nico.core.utils.Color;

public class KitPreview implements CommandExecutor
{
    private final Main plugin;
    net.ess3.api.IEssentials ess;
    
    public KitPreview(final Main plugin) {
        this.ess = (net.ess3.api.IEssentials)Bukkit.getPluginManager().getPlugin("Essentials");
        this.plugin = plugin;
    }
    
    public List<ItemStack> deSerialize(final List<String> items) {
        final List<ItemStack> itemList = new ArrayList<ItemStack>();
        for (final String kitItem : items) {
            final String[] parts = kitItem.split(" +");
            try {
                final ItemStack parseStack = this.ess.getItemDb().get(parts[0], (parts.length > 1) ? Integer.parseInt(parts[1]) : 1);
                if (parseStack == null || parseStack.getType() == Material.AIR) {
                    continue;
                }
                final MetaItemStack metaStack = new MetaItemStack(parseStack);
                if (parts.length > 2) {
                    metaStack.parseStringMeta((CommandSource)null, true, parts, 2, this.ess);
                }
                itemList.add(metaStack.getItemStack());
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return itemList;
    }
    
    public boolean onCommand(final CommandSender pSender, final Command pCmd, final String arg2, final String[] arg3) {
        if (pSender instanceof Player) {
            final Player lPlayer = (Player)pSender;
            if (arg3.length == 0) {
            	lPlayer.sendMessage(Color.color(this.plugin.getConfig().getString("no-params")));
                return true;
            }
            try {
                Kit essentialsKit;
                try {
                    essentialsKit = new Kit(arg3[0], (net.ess3.api.IEssentials)Bukkit.getPluginManager().getPlugin("Essentials"));
                }
                catch (Exception ex) {
                    pSender.sendMessage(ex.getMessage());
                    return true;
                }

                final String[] guiSetup = { "abcdefghi", "jklmnopqr", "stuvwxyz.", "@@@@@@@@@", "@@@@@@@@@", "@@@@~@@@@" };
                final InventoryGui gui = new InventoryGui(this.plugin, null, Color.color(this.plugin.getConfig().getString("kit-title").replace("%kitname%", arg3[0])), guiSetup, new GuiElement[0]);
                final ItemStack invitem = new ItemStack((int)Integer.valueOf(this.plugin.getConfig().getString("dummy-item").split(":")[0]), 1, (short)Short.valueOf(this.plugin.getConfig().getString("dummy-item").split(":")[1]));
                final ItemMeta invmeta = invitem.getItemMeta();
                invmeta.setDisplayName(Color.color(this.plugin.getConfig().getString("dummy-name")));
                invitem.setItemMeta(invmeta);
                gui.setFiller(invitem);
                final ArrayList<String> alphabet = new ArrayList<String>();
                alphabet.add("a");
                alphabet.add("b");
                alphabet.add("c");
                alphabet.add("d");
                alphabet.add("e");
                alphabet.add("f");
                alphabet.add("g");
                alphabet.add("h");
                alphabet.add("i");
                alphabet.add("j");
                alphabet.add("k");
                alphabet.add("l");
                alphabet.add("m");
                alphabet.add("n");
                alphabet.add("o");
                alphabet.add("p");
                alphabet.add("q");
                alphabet.add("r");
                alphabet.add("s");
                alphabet.add("t");
                alphabet.add("u");
                alphabet.add("v");
                alphabet.add("w");
                alphabet.add("x");
                alphabet.add("y");
                alphabet.add("z");
                alphabet.add(".");
                for (final ItemStack item : this.deSerialize(essentialsKit.getItems())) {
                    gui.addElement(new StaticGuiElement(alphabet.get(0).charAt(0), item, click -> true, new String[0]));
                    alphabet.remove(0);
                }
                final ItemStack exit = new ItemStack(Material.BARRIER);
                final ItemMeta exitim = exit.getItemMeta();
                exitim.setDisplayName(ChatColor.RED + "Close");
                exit.setItemMeta(exitim);
                gui.addElement(new StaticGuiElement('~', exit, click -> {
                    gui.close();
                    return true;
                }, new String[0]));
                gui.show((HumanEntity)lPlayer);
                lPlayer.sendMessage(Color.color(this.plugin.getConfig().getString("kit-preview").replace("%kitname%", arg3[0])));
            }
            catch (Exception e) {
                lPlayer.sendMessage(ChatColor.RED + "An exception occured! " + ChatColor.GRAY + ChatColor.ITALIC + '(' + ChatColor.stripColor(e.getMessage()) + ')');
            }
        }
        else {
            pSender.sendMessage(ChatColor.RED + "This command can only be executed by players!");
        }
        return true;
    }
}
