package me.nico.core.utils;

import org.bukkit.ChatColor;

public class Color {

    public static String color(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    public static String removeColor(String message) {
        return ChatColor.stripColor(message);
    }

}
