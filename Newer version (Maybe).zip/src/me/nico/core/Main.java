package me.nico.core;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandExecutor;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import me.nico.core.Commands.DarkZoneStuckCMD;
import me.nico.core.Commands.FriendsCMD;
import me.nico.core.Commands.KitPreview;
import me.nico.core.Commands.LeaveCMD;
import me.nico.core.Commands.MBucketCMD;
import me.nico.core.Commands.RaidOutpost;
import me.nico.core.Commands.ReclaimCMD;
import me.nico.core.Commands.ReloadCMD;
import me.nico.core.Events.BucketEmpty;
import me.nico.core.Events.DeathAnnounce;
import me.nico.core.Events.EntityDamage;
import me.nico.core.Events.IPBlocker;
import me.nico.core.Events.LmsFix;
import me.nico.core.Events.PlayerCommand;
import me.nico.core.Events.ShootBowEvent;
import me.nico.core.Events.StrengthFix;

public class Main extends JavaPlugin {
	@SuppressWarnings("unused")
	private ConfigManager cfgm;

	public File logsFile;
	private FileConfiguration logsConfig;
	public File dataFile;
	private FileConfiguration dataConfig;
	public File friendFile;
	private FileConfiguration friendConfig;
	public static Main instance;
	public List<Integer[]> ints = new ArrayList<>();


	@Override
	public void onEnable() {
		instance = this;

		Integer[] l1 = new Integer[] { -1, 0, 0 };
		Integer[] l2 = new Integer[] { 0, 0, -1 };
		Integer[] l3 = new Integer[] { 1, 0, 0 };
		Integer[] l4 = new Integer[] { 0, 0, 1 };
		Integer[] l5 = new Integer[] { 0, -1, 0 };
		Integer[] l6 = new Integer[] { 0, 1, 0 };
		ints.add(l1);
		ints.add(l2);
		ints.add(l3);
		ints.add(l4);
		ints.add(l5);
		ints.add(l6);

		createCustomConfig();
		LoadConfigManager();
		getConfig().options().copyDefaults(true);
		saveDefaultConfig();
		loadConfig();
		loadData();

		getCommand("darkzonestuck").setExecutor((CommandExecutor) new DarkZoneStuckCMD(this));
		getCommand("tprpost").setExecutor((CommandExecutor) new RaidOutpost(this));
		getCommand("friends").setExecutor((CommandExecutor) new FriendsCMD(this));
		getCommand("reclaim").setExecutor((CommandExecutor) new ReclaimCMD(this));
		getCommand("mbucket").setExecutor((CommandExecutor) new MBucketCMD(this));
		getCommand("4freeCore").setExecutor((CommandExecutor) new ReloadCMD(this));
		getCommand("preview").setExecutor((CommandExecutor) new KitPreview(this));
		getCommand("leave").setExecutor((CommandExecutor) new LeaveCMD(this));
		getServer().getPluginManager().registerEvents(new IPBlocker(this), this);
		getServer().getPluginManager().registerEvents(new DeathAnnounce(this), this);
		getServer().getPluginManager().registerEvents(new BucketEmpty(this), this);
		getServer().getPluginManager().registerEvents(new LmsFix(this), this);
		getServer().getPluginManager().registerEvents(new StrengthFix(this), this);
		getServer().getPluginManager().registerEvents(new EntityDamage(this), this);
		getServer().getPluginManager().registerEvents(new ShootBowEvent(this), this);
		getServer().getPluginManager().registerEvents(new DarkZoneStuckCMD(this), this);
		getServer().getPluginManager().registerEvents(new PlayerCommand(this), this);
		getServer().getConsoleSender().sendMessage(ChatColor.GREEN + "4FreeCore has been enabled!");

	}

	@Override
	public void onDisable() {
		getServer().getConsoleSender().sendMessage(ChatColor.RED + "4FreeCore has been disabled!");
	}


	public void LoadConfigManager() {
		cfgm = new ConfigManager();
	}

	public void loadConfig() {
		getConfig().options().copyDefaults(true);
		saveDefaultConfig();
	}

	public void loadData() {
		getDataConfig().options().copyDefaults(true);
	}

	private void createCustomConfig() {
		logsFile = new File(getDataFolder(), "logs.yml");
		if (!logsFile.exists()) {
			logsFile.getParentFile().mkdirs();
			saveResource("logs.yml", false);
		}

		logsConfig = new YamlConfiguration();
		try {
			logsConfig.load(logsFile);
		} catch (IOException | InvalidConfigurationException e) {
			e.printStackTrace();
		}

		dataFile = new File(getDataFolder(), "data.yml");
		if (!dataFile.exists()) {
			dataFile.getParentFile().mkdirs();
			saveResource("data.yml", false);
		}

		dataConfig = new YamlConfiguration();
		try {
			dataConfig.load(dataFile);
		} catch (IOException | InvalidConfigurationException e) {
			e.printStackTrace();
		}

		friendFile = new File(getDataFolder(), "friends.yml");
		if (!friendFile.exists()) {
			friendFile.getParentFile().mkdirs();
			saveResource("friends.yml", false);
		}

		friendConfig = new YamlConfiguration();
		try {
			friendConfig.load(friendFile);
		} catch (IOException | InvalidConfigurationException e) {
			e.printStackTrace();
		}

	}

	public FileConfiguration getLogsConfig() {
		return this.logsConfig;
	}

	public FileConfiguration getDataConfig() {
		return this.dataConfig;
	}

	public FileConfiguration getFriendConfig() {
		return this.friendConfig;
	}

}
